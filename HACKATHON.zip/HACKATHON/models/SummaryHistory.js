const mongoose = require('mongoose');

const SummaryHistorySchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  repoUrl: {
    type: String,
    required: true
  },
  repoName: {
    type: String,
    required: true
  },
  owner: {
    type: String,
    required: true
  },
  summary: {
    type: String,
    required: true
  },
  isFavorite: {
    type: Boolean,
    default: false
  },
  tags: {
    type: [String],
    default: []
  }
}, {
  timestamps: true
});

// Compound index for efficient querying
SummaryHistorySchema.index({ userId: 1, repoUrl: 1 });
SummaryHistorySchema.index({ userId: 1, isFavorite: 1 });
SummaryHistorySchema.index({ userId: 1, createdAt: -1 });

module.exports = mongoose.model('SummaryHistory', SummaryHistorySchema);