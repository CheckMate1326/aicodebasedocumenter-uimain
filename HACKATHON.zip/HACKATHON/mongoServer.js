const path = require('path');

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'authTestSimple.html'));
});


// mongoServer.js

const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB connection
const MONGO_URI = 'mongodb://localhost:27017/myDB'; // replace 'myDB' with your database name
const PORT = 3000;

mongoose.connect(MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Create a model with no schema (free-form documents)
const AnyModel = mongoose.model('AnyCollection', new mongoose.Schema({}, { strict: false }));

// POST route to add any object
app.post('/data', async (req, res) => {
  try {
    const doc = new AnyModel(req.body);
    await doc.save();
    res.status(201).send(doc);
  } catch (err) {
    res.status(400).send({ error: err.message });
  }
});

// GET route to fetch all documents
app.get('/data', async (req, res) => {
  try {
    const docs = await AnyModel.find();
    res.send(docs);
  } catch (err) {
    res.status(500).send({ error: err.message });
  }
});

const path = require('path');

// Serve the HTML page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'authTestSimple.html'));
});


