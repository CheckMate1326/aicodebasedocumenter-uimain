const express = require("express");
const axios = require("axios"); // to fetch GitHub files
const app = express();
const PORT = 3000;

app.use(express.json()); // to parse JSON from requests

// Test route
app.get("/", (req, res) => {
  res.send("Backend is running 🚀");
});

// New route: summarize repo
app.post("/summarize", async (req, res) => {
  const { repoUrl } = req.body;

  if (!repoUrl) {
    return res.status(400).json({ error: "Repo URL is required" });
  }

  try {
    // Example: fetch the README.md from repo
    const rawUrl = repoUrl.replace(
      "github.com",
      "raw.githubusercontent.com"
    ).replace("/tree/main", "/main") + "/README.md";

    const response = await axios.get(rawUrl);
    const readmeContent = response.data;

    // For now, just send back the README content
    res.json({ readme: readmeContent });
  } catch (error) {
    res.status(500).json({ error: "Could not fetch README" });
  }
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
